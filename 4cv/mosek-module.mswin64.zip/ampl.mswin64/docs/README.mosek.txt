mosek tutorial driver
=======================

The solver "mosek" is a mock solver, provided as an example - and as a template -
on how to getting started using mp with FlatAPI to develop an mp-based solver interface.