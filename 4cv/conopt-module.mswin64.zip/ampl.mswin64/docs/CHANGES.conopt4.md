# Summary of recent updates to CONOPT4 for AMPL

## 20240418
- First released version